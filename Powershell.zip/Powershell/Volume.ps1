﻿Get-Audiodevice -list
Set-Audiodeive -id <string>
Set-AudioDevice -PlaybackMute 0
Set-AudioDevice -PlaybackVolume 40
Set-AudioDevice -RecordingVolume 50 
pause /exit